import arcpy
import os
import ee
import pandas as pd

def getGeeElevation(workspace, csv_file, outfc_name, epsg=4326):
    # Initialize Earth Engine
    try:
        ee.Initialize(project="ee-egyinhayford01")
    except Exception:
        ee.Authenticate()
        ee.Initialize()

    # Load the CSV file
    csv_path = os.path.join(workspace, csv_file)
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV file not found at {csv_path}")
    data = pd.read_csv(csv_path)

    # Ensure X and Y columns exist
    if not {'X', 'Y'}.issubset(data.columns):
        raise ValueError("CSV must contain 'X' and 'Y' columns.")

    # Create geometry from X and Y
    geometries = [
        ee.Geometry.Point([x, y], f"EPSG:{epsg}") for x, y in zip(data['X'], data['Y'])
    ]
    fc = ee.FeatureCollection(geometries)

    # Sample elevation data
    dem = ee.Image("USGS/3DEP/10m")
    sampled_fc = dem.sampleRegions(
        collection=fc, scale=10, geometries=True
    )
    sampled_info = sampled_fc.getInfo()

    # Update elevation data in the original features
    origin_info = fc.getInfo()
    for ind, itm in enumerate(origin_info['features']):
        itm['properties'] = sampled_info['features'][ind]['properties']

    # Create the output feature class
    fcname = os.path.join(workspace, outfc_name)
    if arcpy.Exists(fcname):
        arcpy.management.Delete(fcname)
    arcpy.management.CreateFeatureclass(workspace, outfc_name, geometry_type='POINT', spatial_reference=epsg)

    # Add 'elevation' field to the feature class
    arcpy.management.AddField(fcname, field_name='elevation', field_type='FLOAT')

    # Insert rows into the feature class
    with arcpy.da.InsertCursor(fcname, ['SHAPE@', 'elevation']) as cursor:
        for feat in origin_info['features']:
            coords = feat['geometry']['coordinates']
            pnt = arcpy.PointGeometry(
                arcpy.Point(coords[0], coords[1]),
                spatial_reference=epsg
            )
            elev = feat['properties']['elevation']
            cursor.insertRow([pnt, elev])

def main():
    # Check for correct number of arguments
    if len(sys.argv) != 5:
        raise ValueError("Usage: python project2.py <workspace> <csv_file> <outfc_name> <epsg>")

    workspace = sys.argv[1]
    csv_file = sys.argv[2]
    outfc_name = sys.argv[3]
    epsg = int(sys.argv[4])

    # Validate workspace
    if not os.path.exists(workspace):
        raise FileNotFoundError(f"Workspace directory does not exist: {workspace}")

    # Call the function
    getGeeElevation(workspace=workspace, csv_file=csv_file, outfc_name=outfc_name, epsg=epsg)

if __name__ == "__main__":
    main()
